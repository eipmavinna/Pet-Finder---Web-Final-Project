document.addEventListener("DOMContentLoaded", async () => {
    
    console.log("in typescript")
    
    const form = document.getElementById("filterForm") as HTMLFormElement;
    console.log("running");
    form.addEventListener("submit", async (event) => {
        event.preventDefault();
        console.log("hit submit");
        await getFilteredPets();
    });
    const submitBtn = <HTMLButtonElement> document.getElementById("submit-btn");

        const favButton = document.getElementById("favorite-button");
        if(await IsLoggedInSearch()){
            console.log("logged in");
            favButton.addEventListener("click", () => addToFavoritesSearch(favButton.dataset.petId));
        }else{
            favButton.remove()
        }
    
    
    const profileBtn = document.getElementById("profile");
    profileBtn.addEventListener("click", async function (e){
        e.preventDefault();
        e.stopImmediatePropagation();
        if(await IsLoggedInSearch()){
            window.location.href = '/profile/';
            return;
        }
        const loginModal = document.getElementById("profileModal");
        const modal = (window as any).bootstrap.Modal.getOrCreateInstance(loginModal);
        modal.show();
    });
});





async function getFilteredPets(){
    const form = <HTMLFormElement> document.getElementById("filterForm");
    const formData = new FormData(form);

    if (isFormDataEmpty(formData)) {
        // give the user feedback and avoid the empty request
        alert("Please fill at least one filter field.");
        console.log("empty")
        return;
    }

    //give the form data to the /search route
    const response = await fetch("/search/", {
            method: "POST",
            headers: {
                "Accept": "application/json"
            },
            body: formData
    });

    const data = await validateJSONSearch(response);


    makeButtonsSearch(data.results);

}

//checks if no data was put into the form meaning it was submitted with no input data
function isFormDataEmpty(formData: FormData) {

    const zip = formData.get("zipcode") as string | null;
    const type = formData.get("animal_type") as string | null;
    const age = formData.get("age_group") as string | null;

    if ((zip && zip !== "" )|| (type && type !== "") || (age && age !== "")) {
        return false;
    }

  return true;
}

async function IsLoggedInSearch(): Promise<boolean>{
        const response = await fetch(`/api/isLoggedIn/`, {
            method: "GET",
            headers: {
                "Accept": "application/json"
            }
        });
        const data = await validateJSONSearch(response);
        return data.signedIn;
}


async function makeButtonsSearch(list: string[]){
    const buttonDiv = <HTMLDivElement> document.getElementById("buttons-div")
    buttonDiv.replaceChildren();
    for(const id of list){
        //make a div for each new button
        const newDiv = <HTMLDivElement> document.createElement("div");
        buttonDiv.appendChild(newDiv);
        loadHomePetsSearch(id, newDiv)
    }
}



async function loadHomePetsSearch(id: string, newDiv: HTMLDivElement){

        const btn = <HTMLButtonElement> document.createElement('button');
        btn.addEventListener("click",() => changeDataSearch(id));
        btn.classList.add("petButton");
        btn.setAttribute("data-pet-id", id);
        btn.setAttribute("data-bs-toggle", "modal");
        btn.setAttribute("data-bs-target","#exampleModal");


        const baseURL = "https://api.rescuegroups.org/v5/";
        const animalsURL = `${baseURL}public/animals/${id}`

        const response = await fetch(animalsURL, {
                method: "GET",
                headers: {
                    "Content-Type": "application/vnd.api+json",
                    "Authorization": "7mZmJj1Y", 
                },
        });


        const pet = await validateHomeJSONSearch(response);

        //get the information we need from the API
        //name , orgID, imageURL

        let name = pet.data[0].attributes.name;
        if(name.toLowerCase().includes("adopted")){
            return;
        }
        const orgsID = pet.data[0].relationships.orgs.data[0].id;
        const imageURL = pet.data[0].attributes.pictureThumbnailUrl;

            
        const orgsURL= `${baseURL}public/orgs/${orgsID}`;
        const response2 = await fetch(orgsURL, {
                method: "GET",
                headers: {
                    "Content-Type": "application/vnd.api+json",
                    "Authorization": "7mZmJj1Y", 
                },
        });

        //get the organization information we need from the api
            
        const organizations = await validateHomeJSONSearch(response2);

        const orgLocationCity = organizations.data[0].attributes.citystate;


        //get the image or set it to the image stub if none is provided
        if(imageURL == null){
            btn.innerHTML = `<img src="/static/icons/petStubImage.png" alt="No stub Available"><p>${name}</p><p>${orgLocationCity}</p>`;

        }else{
            btn.innerHTML = `<img src="${imageURL}" alt="No Image Available"><p>${name}</p><p>${orgLocationCity}</p>`;
        }
        

        newDiv.append(btn)
    
}


async function validateHomeJSONSearch(response: Response): Promise<any> {
    if (response.ok) {
        return response.json();
    } else {
        return Promise.reject(response);
    }
}


    async function changeDataSearch(pid: string){
        //fill the modal that has been clicked
        fillModalSearch(pid);

        //set fav button petID so it can add or remove the pet id from the db
        if(await IsLoggedInSearch()){
            const favButton = document.getElementById("favorite-button");
            if(favButton != null){
                favButton.dataset.petId = pid;
                console.log("favButton id: "+ favButton.dataset.petId)
                //if isfavorite, "Delete from favs", else "Add to favs"
                if(await isFavoriteSearch(pid)){
                    //favButton.innerText = "Delete from favorites"
                    favButton.innerHTML = `<img src="/static/icons/unfavorite.png" alt="Unfavorite" width="24" height="24">`;
                }else{
                    //favButton.innerText = "Add to favorites"
                    favButton.innerHTML = `<img src="/static/icons/favorite.png" alt="Favorite" width="24" height="24">`;
                }
            }
            console.log("is favorite: " + await isFavoriteSearch(pid))
        }
        
    }


    async function isFavoriteSearch(petId: string): Promise<boolean> {
        const response = await fetch(`/api/favoritePet/check/${encodeURIComponent(petId)}`, {
            method: "GET",
            //credentials: "same-origin", // send session cookie
            headers: {
                "Accept": "application/json"
            }
        });
        const data = await validateJSONSearch(response);  // <— pass Response, NOT parsed JSON
        return data.exists;
    }



    async function addToFavoritesSearch(petId: string){
        //if "Delete from favorites" change to "Add to favorites", etc
        const favButton = document.getElementById("favorite-button");
        if(await isFavoriteSearch(petId)){
            if(favButton){
                favButton.innerHTML = `<img src="/static/icons/favorite.png" alt="Favorite" width="24" height="24">`;
            }

        }else{
            if(favButton){
                favButton.innerHTML = `<img src="/static/icons/unfavorite.png" alt="Unfavorite" width="24" height="24">`;
            }
        }
        //want to access the FavPet table and add something with the user's id and the pet id
        await fetch("/api/favoritePet/", {
            method: "POST",
            credentials: "same-origin", // send session cookie
            headers: {"Content-Type":"application/json"},
            body: JSON.stringify({pid: petId})
        })
        console.log("added " + petId)
    }


    async function fillModalSearch(id: string){
        const modalBodyDiv = document.getElementById("bodyDiv");
        const baseURL = "https://api.rescuegroups.org/v5/";
        const animalsURL = `${baseURL}public/animals/${id}`

        const response = await fetch(animalsURL, {
            method: "GET",
            headers: {
                "Content-Type": "application/vnd.api+json",
                "Authorization": "7mZmJj1Y", 
            },
        });

        const pet = await validateHomeJSONSearch(response);

        //get the modal information we need from the api
        //name, age, gender, breed, description, orgID, imageURL
        const name = document.getElementById("petName");
        if(name){
            name.textContent = "Name: " + (pet.data[0].attributes.name ?? "N/A");
        }
        
        
        const ageGroup = document.getElementById("petAge");
        if(ageGroup){
            ageGroup.textContent = "Age: " + (pet.data[0].attributes.ageGroup ?? "N/A");
        }
        

        const gender =  document.getElementById("petGender");
        if(gender){
           gender.textContent = "Gender: " + (pet.data[0].attributes.sex ?? "N/A"); 
        }
        

        const breed = document.getElementById("petBreed");
        if(breed){
            breed.textContent = "Breed: " + (pet.data[0].attributes.breedString ?? "N/A");
        }
        

        const description = document.getElementById("petDescription");
        if(description){
            description.textContent = "Description: " + (pet.data[0].attributes.descriptionText ?? "N/A");
        }
        


        const orgsID = pet.data[0].relationships.orgs.data[0].id;
        const imageURL = pet.data[0].attributes.pictureThumbnailUrl;  

            
        const orgsURL= `${baseURL}public/orgs/${orgsID}`;
        const response2 = await fetch(orgsURL, {
                method: "GET",
                headers: {
                    "Content-Type": "application/vnd.api+json",
                    "Authorization": "7mZmJj1Y", 
                },
        });
        
        //get the organization information we need from the api

        const organizations = await validateHomeJSONSearch(response2);

        //getting the organization city/state
        const orgLocationCity = document.getElementById("petLocation");
        if(orgLocationCity){
            orgLocationCity.textContent = "Location: " + (organizations.data[0].attributes.citystate ?? "N/A");
        }
        
        const petURL = document.getElementById("petURL") as HTMLAnchorElement;
        petURL.href = organizations.data[0].attributes.url ?? "#";

       const img = <HTMLImageElement> document.getElementById("petImage")
        
       //add the image or put in the stub image if none is provided
        if(imageURL == null){
            img.src = '/static/icons/petStubImage.png';
            img.alt = 'No stub Available';
            if(modalBodyDiv){
                modalBodyDiv.append(img);
            }
            
        }else{
            img.src = imageURL;
            img.alt = 'No Image Available';
            if(modalBodyDiv){
                modalBodyDiv.append(img);
            }
        }

    }


    async function validateJSONSearch(response: Response): Promise<any> {
        if (response.ok) {
            return response.json();
        } else {
            return Promise.reject(response);
        }
    }

    

