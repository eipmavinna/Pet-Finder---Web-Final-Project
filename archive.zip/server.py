from app import create_app
# construct an app using the default config options
app = create_app()  # <<runs init

#user id, id of pet