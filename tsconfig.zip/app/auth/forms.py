from flask_wtf import FlaskForm
from wtforms import EmailField, PasswordField, SubmitField, IntegerField, StringField
from wtforms.validators import InputRequired, Email, Length

MIN_PASSWORD_LENGTH: int = 8

class LoginForm(FlaskForm):
    email: EmailField = EmailField('Email',
        validators=[InputRequired(), Email()])
    password: PasswordField = PasswordField('Password',
        validators=[InputRequired(), Length(min=MIN_PASSWORD_LENGTH)])
    submit: SubmitField = SubmitField("Login")

#adding signup forms here
class SignupFormUser(FlaskForm):
    
    #TODO make it so that the email field checks the current users and shelters to make sure there isn't another acct made with the same email

    email: EmailField = EmailField('Email',
        validators=[InputRequired(), Email()])
    password: StringField = StringField('Password',
        validators=[InputRequired(), Length(min=MIN_PASSWORD_LENGTH)])
    zipcode: StringField = StringField(validators=[InputRequired(), Length(min=5,max=5)])
    submit: SubmitField = SubmitField("Sign Up")


#right now there's no verification, but I think that's fine for now
class SignupFormShelter(FlaskForm):

    #TODO make it so that the email field checks the current users and shelters to make sure there isn't another acct made with the same email
    

    email: EmailField = EmailField("Email", validators=[InputRequired(), Email()])
    password: StringField = StringField('Password',
        validators=[InputRequired(), Length(min=MIN_PASSWORD_LENGTH)])
    street_address: StringField = StringField("Street Address",validators=[InputRequired()])
    city: StringField = StringField("City",validators=[InputRequired()])
    state: StringField = StringField("State", validators=[InputRequired()])
    zipcode: StringField = StringField(validators=[InputRequired(), Length(min=5,max=5)])
    submit: SubmitField = SubmitField('Verify')
    
    
